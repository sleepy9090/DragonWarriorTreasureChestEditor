﻿DragonWarriorTreasureChestEditor 1.0.0.23238
Coded by: Shawn M. Crawford [sleepy9090]
February 9, 2018

-Requires .NET Framework 3.5

DragonWarriorTreasureChestEditor 
Program to treasure chest locations and contents for Dragon Warrior NES ROM.

-Tested with headered Dragon Warrior (U) (PRG0) [!].nes ROM.
-Tested with headered Dragon Warrior (U) (PRG1) [!].nes ROM.

Feel free to send bugs to sleepy3d@email.com or file them on github: https://github.com/sleepy9090

Version: 1.0.0.23238 February 9, 2018
-first version


